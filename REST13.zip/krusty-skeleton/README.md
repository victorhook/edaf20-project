# README

How to run:

    $ gradlew run

or:

    $ gradlew shadowJar
    $ java -jar build/libs/krusty-1.0-all.jar
